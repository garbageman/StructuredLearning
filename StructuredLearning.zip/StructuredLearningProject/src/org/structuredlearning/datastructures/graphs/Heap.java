package org.structuredlearning.datastructures.graphs;

import java.util.Comparator;
import java.util.Set;

public class Heap<E> {

	public Heap(Comparator<E> comparator) {
		
	}
	
	/**
	 * Adds element to the heap
	 * @param element
	 * @return true if add is successful, false otherwise
	 */
	public boolean add(E element) {
		return false;
	}
	
	/**
	 * Returns true if the heap contains the value
	 * @param o
	 * @return
	 */
	public boolean contains(Object o) {
		return false;
	}
	
	/**
	 * Returns the top of the heap without removing it
	 * @return element at top of the heap
	 */
	public E peek() {
		return null;
	}
	
	/**
	 * Removes the top of the heap and removes it
	 * @return element at the top of the heap
	 */
	public E pop() {
		return null;
	}
	
	/**
	 * Removes the element from the heap
	 * @param o
	 * @return true if element was removed, false otherwise
	 */
	public boolean remove(Object o) {
		return false;
	}
	
	/**
	 * Returns the size of the heap
	 * @return size of heap
	 */
	public int size() {
		return 0;
	}
	

}
