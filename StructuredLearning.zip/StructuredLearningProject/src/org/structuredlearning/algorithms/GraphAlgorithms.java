package org.structuredlearning.algorithms;

import java.util.Set;

import org.structuredlearning.datastructures.graphs.UWGraph;

public class GraphAlgorithms {
	
	/**
	 * Given a graph g and an element e, find all the elements in the graph connected to it
	 * @param <E>
	 * @param g
	 * @param e
	 * @return set of elements connected to element
	 */
	public static <E> Set<E> bfs(UWGraph<E> g, E e) {
		return null;
	}
}
